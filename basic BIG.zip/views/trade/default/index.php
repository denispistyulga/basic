<?
use app\models\trade\Category;
use app\widgets\MenuWidget;

//echo '<pre>';
//$result = Category::getCategoryAll();
//print_r($result);

echo '<div style="width:300px;float:left; padding:10px; border:1px solid #074776">';
echo $menu;
echo '</div>';


//echo MenuWidget::widget();

?>